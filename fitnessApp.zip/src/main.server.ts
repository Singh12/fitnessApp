import { enableProdMode } from '@angular/core';

export { AppServerModule } from './app/app.server.module';
enableProdMode();
