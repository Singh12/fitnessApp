export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyBiCsoicfSk-inZ8B_0vAWZRGtbexaoSzY',
    authDomain: 'fitness-670db.firebaseapp.com',
    databaseURL: 'https://fitness-670db.firebaseio.com',
    projectId: 'fitness-670db',
    storageBucket: 'fitness-670db.appspot.com',
    messagingSenderId: '110147103087'
  }
};
